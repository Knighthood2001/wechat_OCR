# 前言

**关于 wechat-ocr 库版本兼容性问题的说明**

`kanadeblisst00` 开发者创建了一个名为 `wechat-ocr` 的优秀项目，但目前 PyPI 上仅发布了 0.0.3 版本。

如果您直接使用 `pip install wechat-ocr` 安装该库，在新版微信环境下可能会遇到运行问题。这是因为当微信客户端升级到4.1.0.34 等较新版本后，其内部文件结构发生了变化。

具体来说，新版本的微信安装目录中只包含 `mmmojo_64.dll` 动态链接库文件，而不再提供 `mmmojo.dll` 文件。然而，`wechat-ocr 0.0.3` 版本的源代码默认尝试加载的是 `mmmojo.dll`，这就导致了库文件找不到的兼容性问题。

为了解决这个版本不匹配的问题，需要手动修改 `wechat-ocr` 的源代码，将其 DLL 加载逻辑调整为优先识别或兼容 `mmmojo_64.dll` 文件，以确保能够在新版微信环境中正常运行。

# 安装

```bash
git clone https://github.com/Knighthood2001/wechat_ocr_pkg.git
cd wechat_ocr_pkg
pip install dist/wechat_ocr-0.0.4.tar.gz
```



# 使用

测试案例在tests/case.py[测试代码](tests/case.py)中。记得修改里面的wechat_ocr_dir，wechat_dir以及要识别的图片地址。


# 修改内容

我主要修改了src\wechat_ocr\xplugin_manager.py文件。


```python
    def __init__(self, wechat_path) -> None:
        def find_mmmojo_dll():
            for dll_name in ["mmmojo_64.dll", "mmmojo.dll"]:
                mmmojo_dll_path = os.path.join(wechat_path, dll_name)
                if os.path.exists(mmmojo_dll_path):
                    return mmmojo_dll_path
            return None
        mmmojo_dllpath = find_mmmojo_dll()
        if not mmmojo_dllpath:
            raise Exception("给定的微信路径不存在mmmojo_64.dll或者mmmojo.dll")
        self._dll = MmmojoDll(mmmojo_dllpath)
        self.m_cb_usrdata = self
        # 增加callback的引用计数，防止被垃圾回收机制处理
        self._callbacks_refer = {}
```

# 自己修改

当然，我目前没有经过多个设备的测试，如果你自己电脑上出现问题，可以自行修改源码。

然后进行构建

```shell
pip install build
```

执行构建，会在dist中生成*.tar.gz和*.whl文件

```shell
python -m build
```

然后你就可以进行安装了

```bash
pip install dist/wechat_ocr-0.0.4.tar.gz
``` 

或者是进行可编辑模式安装

```bash
pip install -e .
```